# Restrict-Taxonomies
Wordpress Plugin based on Restrict Categories, works with custom taxonomies


* Contributors: sladix, mmuro
* Tags: restrict, admin, administration, cms, categories, category, taxonomies, taxonomy
* Requires at least: 3.1
* Tested up to: 4.4.2
* Stable tag: 1.3.0
* License: GPLv2 or later
* License URI: http://www.gnu.org/licenses/gpl-2.0.html
