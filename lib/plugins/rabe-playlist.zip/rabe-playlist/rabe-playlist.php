<?php
/*
   Plugin Name: Rabe-Playlist
   Plugin URI: https://momou.ch
   Description: Playlist functionality for RaBe website
   Version: 0.2
   Author: momou!
   Author URI: https://momou.ch
   License: ?
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/**
 * Admin
 * Stolen from here: https://codex.wordpress.org/Creating_Options_Pages
 * -----------------------------------------------------------------------------
 **/

class RabePlaylistSettingsPage {
	/**
	 * Holds the values to be used in the fields callbacks
	 */
	private $options;
	
	/**
	 * Start up
	 */
	public function __construct()
	{
		add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
		add_action( 'admin_init', array( $this, 'page_init' ) );
	}

	/**
	 * Add options page
	 */
	public function add_plugin_page()
	{
		// This page will be under "Settings"
		add_options_page(
			'Settings Admin',
				'RaBe Playlist', 
				'manage_options', 
				'rabe-playlist-setting-admin', 
				array( $this, 'create_admin_page' )
		);
	}
	
	/**
	 * Options page callback
	 */
	public function create_admin_page()
	{
		// Set class property
		$this->options = get_option( 'rabe_playlist_options' );
?>
	<div class="wrap">
		<h2>RaBe Playlist Settings</h2>           
		<form method="post" action="options.php">
			<?php
			// This prints out all hidden setting fields
			settings_fields( 'my_option_group' );   
			do_settings_sections( 'rabe-playlist-setting-admin' );
			submit_button(); 
			?>
		</form>
	</div>
<?php
}

/**
 * Register and add settings
 */
public function page_init()
{        
	register_setting(
		'my_option_group', // Option group
			'rabe_playlist_options', // Option name
			array( $this, 'sanitize' ) // Sanitize
	);

	add_settings_section(
		'setting_section_id', // ID
			'RaBe Playlist Custom Settings', // Title
			array( $this, 'print_section_info' ), // Callback
			'rabe-playlist-setting-admin' // Page
	);  

	add_settings_field(
		'text', // ID
			'Custom text before playlist', // Title 
			array( $this, 'text_callback' ), // Callback
			'rabe-playlist-setting-admin', // Page
			'setting_section_id' // Section           
	);      
}

/**
 * Sanitize each setting field as needed
 *
 * @param array $input Contains all settings fields as array keys
 */
public function sanitize( $input )
{
	$new_input = array();
	if( isset( $input['text'] ) )
		$new_input['text'] = sanitize_text_field( $input['text'] );

	return $new_input;
}

/** 
 * Print the Section text
 */
public function print_section_info()
{
	print 'Enter your settings below:';
}

/** 
 * Get the settings option array and print one of its values
 */
public function text_callback()
{
	printf(
		'<input type="text" id="text" name="rabe_playlist_options[text]" value="%s" />',
			isset( $this->options['text'] ) ? esc_attr( $this->options['text']) : ''
	);
}
}

if( is_admin() )
	$rabe_playlist_settings_page = new RabePlaylistSettingsPage();



/**
 * DB
 * -----------------------------------------------------------------------------
 **/


function rbpl_create_tables () {
	//global $rbpl_db_version;
	$rbpl_db_version = '2.0';

	global $wpdb;
	$installed_ver = get_option( "rbpl_db_version" );

	/* global $rbpl_db_version; */

	/* update_option( 'rbpl_db_version', $rbpl_db_version );
	 */
	$table_name_bc = $wpdb->prefix . 'rbpl_broadcast';
	$table_name_track = $wpdb->prefix . 'rbpl_track';

	// Should we migrate?
	if ( $installed_ver == '1.0' | $installed_ver == '' ) {
		$table_name_new = $wpdb->prefix . 'rbpl_playlist';
		
		$charset_collate = $wpdb->get_charset_collate();
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );


		
		// Create new table
		$sql = "                
                CREATE TABLE $table_name_new (
                  track_id INT UNSIGNED AUTO_INCREMENT NOT NULL,
                  artist VARCHAR(255),
                  title VARCHAR(255),
                  start datetime,
                  end datetime,
		  broadcast VARCHAR(255) NOT NULL,
		  bc_start datetime NOT NULL,
		  bc_end datetime NOT NULL,
                  PRIMARY KEY (track_id)
                ) $charset_collate;
                ";
		dbDelta( $sql );

		// Migrate data into new tables (only if not new install)
		if ( $installed_ver == '1.0' ) {

//			dbDelta( "create table wp_rbpl_dubidubi (test varchar(1)) $charset_collate;" );
			$wpdb->query(
				$wpdb->prepare(
			
			"
                        insert into $table_name_new
                          (artist, title, start, end, broadcast, bc_start, bc_end)
                        select distinct
                          tr.artist,
                          tr.title,
                          tr.start,
                          tr.end,
                          bc.broadcast,
                          bc.bc_start,
                          bc.bc_end
                        FROM $table_name_track tr
                        RIGHT JOIN $table_name_bc bc ON tr.show_uuid = bc.show_uuid;
                        $charset_collate;
                        "
				)
			);
			
			
			// TODO Delete old table
			
		}
		// TODO: Wieso hat das nicht funktioniert?????
		// wp_cache_delete ( 'alloptions', 'options' );
		update_option( 'rbpl_db_version', $rbpl_db_version );
	}


	
	/* if($wpdb->get_var("show tables like '$table_name_bc'") != $table_name_bc) {

	   $charset_collate = $wpdb->get_charset_collate();

	   $sql = "                
           CREATE TABLE $table_name_bc (
           show_id INT UNSIGNED AUTO_INCREMENT NOT NULL,
           show_uuid VARCHAR(36) NOT NULL,
           broadcast VARCHAR(255) NOT NULL,
           bc_start datetime NOT NULL,
           bc_end datetime,
           UNIQUE (show_uuid),
           PRIMARY KEY (show_id)
           ) $charset_collate;
           
           CREATE TABLE $table_name_track (
           track_id INT UNSIGNED AUTO_INCREMENT NOT NULL,
           track_uuid VARCHAR(36) NOT NULL,
           show_uuid VARCHAR(36) NOT NULL,
           artist VARCHAR(255) NOT NULL,
           title VARCHAR(255) NOT NULL,
           start datetime NOT NULL,
           end datetime,
           FOREIGN KEY (show_uuid) REFERENCES $table_name_bc(show_uuid),
           PRIMARY KEY (track_id),
           UNIQUE (track_uuid)
           ) $charset_collate;
           ";
	   
	   require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	   dbDelta( $sql );
	   
	   add_option( 'rbpl_db_version', $rbpl_db_version );

	   } */
}

//register
register_activation_hook( __FILE__, 'rbpl_create_tables' );

//probieren wir mal was auszugeben
function rbpl_db_get_results ($playlist_date) {
	global $wpdb;

	$installed_ver = get_option( "rbpl_db_version" );

	$table_name_track = $wpdb->prefix . 'rbpl_track';
	$table_name_bc = $wpdb->prefix . 'rbpl_broadcast';
	$table_name_new = $wpdb->prefix . 'rbpl_playlist';

	$playlist_date_from = $playlist_date . ' 00:00:00';
	$playlist_date_to   = $playlist_date . ' 23:59:59';

	// In case of old database
	if ( $installed_ver == '1.0' ) {
		return $wpdb->get_results( "
                   SELECT DISTINCT
                   tr.track_id,
                   bci.broadcast,
                   t.slug link,
                   bci.bc_start,
                   bci.bc_end,
                   tr.artist,
                   tr.title,
                   tr.start,
                   tr.end 
                   FROM
                   $table_name_track tr
                   RIGHT JOIN
                   $table_name_bc bci ON tr.show_uuid = bci.show_uuid
                   LEFT JOIN
                   wp_terms t ON t.name = bci.broadcast
        
                   WHERE (tr.end   > '$playlist_date_from' 
                     OR bci.bc_end > '$playlist_date_from')
                   AND  (tr.start <= '$playlist_date_to' 
                     OR bci.bc_start <= '$playlist_date_to')
                   ORDER BY bc_start DESC, start DESC
                   "
        	);		
	} elseif ( $installed_ver == '2.0' ) {
		return $wpdb->get_results( "
                   SELECT
                   pl.broadcast,
                   t.slug link,
                   pl.bc_start,
                   pl.bc_end,
                   pl.artist,
                   pl.title,
                   pl.start,
                   pl.end 
                   FROM
                   $table_name_new pl
                   LEFT JOIN
                   wp_terms t ON t.name = pl.broadcast
        
                   WHERE (pl.end   > '$playlist_date_from' 
                     OR pl.bc_end > '$playlist_date_from')
                   AND  (pl.start <= '$playlist_date_to' 
                     OR pl.bc_start <= '$playlist_date_to')
                   ORDER BY bc_start DESC, start DESC
                   "
        	);
	}
}



function rbpl_db_update_table () {

	global $wpdb;
	$installed_ver = get_option( "rbpl_db_version" );
	
	$table_name_bc = $wpdb->prefix . 'rbpl_broadcast';
	$table_name_track = $wpdb->prefix . 'rbpl_track';
	$table_name_new = $wpdb->prefix . 'rbpl_playlist';

	$ticker_url = "http://intranet.rabe.ch/songticker/0.9.3/current.xml";
	$ticker_xml = simplexml_load_string(file_get_contents($ticker_url));


	if ($ticker_xml) {
		if ( $installed_ver == '1.0' ) {
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO $table_name_new(show_uuid, broadcast, bc_start, bc_end)
                                         SELECT %s,%s,%s,%s
                                         FROM (SELECT 1) AS a
                                         WHERE NOT EXISTS(
                                           SELECT show_uuid
                                           FROM $table_name_bc
                                           WHERE show_uuid = %s
                                         ) LIMIT 1;",
						$ticker_xml->show["id"],
						$ticker_xml->show->name,
						$ticker_xml->show->startTime,
						$ticker_xml->show->endTime,
						$ticker_xml->show["id"]
				)
			);

			
			// TODO: wenn end - start < 30sekunden dann nicht!
			if (!($ticker_xml->track->artist == 'Radio Bern' &&
				$ticker_xml->track->title == 'Livestream')) {
				$wpdb->query(
					$wpdb->prepare(
						"INSERT INTO $table_name_track(track_uuid, show_uuid, artist, title, start, end)
                   SELECT %s,%s,%s,%s,%s,%s
                   FROM (SELECT 1) AS a
                   WHERE NOT EXISTS(
                     SELECT track_uuid
                     FROM $table_name_track
                     WHERE track_uuid = %s
                   ) LIMIT 1;",
							$ticker_xml->track["id"],
							$ticker_xml->show["id"],
							$ticker_xml->track->artist,
							$ticker_xml->track->title,
							$ticker_xml->track->startTime,
							$ticker_xml->track->endTime,
							$ticker_xml->track["id"]
					)
						
				);
			}
		} elseif ( $installed_ver == '2.0' ) {

			// TODO: wenn end - start < 30sekunden dann nicht!
			if (($ticker_xml->track->artist == 'Radio Bern' &&
				$ticker_xml->track->title == 'Livestream')) {

				$wpdb->query(
					$wpdb->prepare(
						"INSERT INTO $table_name_new(artist, title, start, end, broadcast, bc_start, bc_end)
                                         SELECT NULL,NULL,NULL,NULL,%s,%s,%s
                                         FROM (SELECT 1) AS a
                                         WHERE NOT EXISTS(
                                           SELECT artist, title, start, end, broadcast, bc_start, bc_end
                                           FROM $table_name_new
                                           WHERE artist IS NULL
                                             AND title IS NULL
                                             AND start IS NULL
                                             AND end IS NULL
                                             AND broadcast = %s
                                             AND bc_start = %s
                                             AND bc_end = %s
                                         ) LIMIT 1;",
							$ticker_xml->show->name,
							$ticker_xml->show->startTime,
							$ticker_xml->show->endTime,
							$ticker_xml->show->name,
							$ticker_xml->show->startTime,
							$ticker_xml->show->endTime
					)
				);

				

			} else {
				
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO $table_name_new(artist, title, start, end, broadcast, bc_start, bc_end)
                                         SELECT %s,%s,%s,%s,%s,%s,%s
                                         FROM (SELECT 1) AS a
                                         WHERE NOT EXISTS(
                                           SELECT artist, title, start, end, broadcast, bc_start, bc_end
                                           FROM $table_name_new
                                           WHERE artist = %s 
                                             AND title = %s
                                             AND start = %s
                                             AND end = %s
                                             AND broadcast = %s
                                             AND bc_start = %s
                                             AND bc_end = %s
                                         ) LIMIT 1;",
						$ticker_xml->track->artist,
						$ticker_xml->track->title,
						$ticker_xml->track->startTime,
						$ticker_xml->track->endTime,
						$ticker_xml->show->name,
						$ticker_xml->show->startTime,
						$ticker_xml->show->endTime,
						$ticker_xml->track->artist,
						$ticker_xml->track->title,
						$ticker_xml->track->startTime,
						$ticker_xml->track->endTime,
						$ticker_xml->show->name,
						$ticker_xml->show->startTime,
						$ticker_xml->show->endTime
				)
			);
			}
		}
	}
}


//register_activation_hook( __FILE__, 'insert_ticker' );



// öhm. wenn plugin aktiviert wird einen scheduler einhängen.
register_activation_hook( __FILE__, 'rbpl_db_schedule' );

function rbpl_db_schedule () {
	$timestamp = wp_next_scheduled( 'rbpl_db_update_every_minute' );

	if( $timestamp == false ) {
		wp_schedule_event( time(), 'every_minute', 'rbpl_db_update_every_minute');
	}
}

add_action( 'rbpl_db_update_every_minute', 'rbpl_db_update_table' );

// den scheduler every_minute machen
add_filter( 'cron_schedules', 'rbpl_add_every_minute_schedule');
function rbpl_add_every_minute_schedule( $schedules ) {
	$schedules['every_minute'] = array(
		'interval' => 60,
			'display' => 'Every Minute' // TODO: __( 'Every Minute', 'rbpl_domain' )
	);
	return $schedules;
}

// den scheduler wieder aushängen
register_deactivation_hook( __FILE__, 'rbpl_remove_db_schedule' );
function rbpl_remove_db_schedule () {
	wp_clear_scheduled_hook( 'rbpl_db_update_every_minute' );
}




// jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj

// also: machen wir ein template?
// http://www.wpexplorer.com/wordpress-page-templates-plugin/

class PageTemplater {

	/**
         * A Unique Identifier
         */
	protected $plugin_slug;

        /**
         * A reference to an instance of this class.
         */
        private static $instance;

        /**
         * The array of templates that this plugin tracks.
         */
        protected $templates;
	
	/**
	 * Returns an instance of this class. 
	 */
	public static function get_instance() {

		if( null == self::$instance ) {
			self::$instance = new PageTemplater();
		} 

		return self::$instance;

	}

	/**
	 * Initializes the plugin by setting filters and administration functions.
	 */
	private function __construct() {

		$this->templates = array();


		// Add a filter to the attributes metabox to inject template into the cache.
		add_filter(
			'page_attributes_dropdown_pages_args',
				array( $this, 'register_project_templates' ) 
		);


		// Add a filter to the save post to inject out template into the page cache
		add_filter(
			'wp_insert_post_data', 
				array( $this, 'register_project_templates' ) 
		);


		// Add a filter to the template include to determine if the page has our 
		// template assigned and return it's path
		add_filter(
			'template_include', 
				array( $this, 'view_project_template') 
		);


		// Add your templates to this array.
		$this->templates = array(
			'page-playlist.php'     => 'RaBe Playlist', //TODO: Noch rausziehen
		);
		
	}
	
	public function register_project_templates( $atts ) {

		// Create the key used for the themes cache
		$cache_key = 'page_templates-' . md5( get_theme_root() . '/' . get_stylesheet() );

		// Retrieve the cache list. 
		// If it doesn't exist, or it's empty prepare an array
		$templates = wp_get_theme()->get_page_templates();
		if ( empty( $templates ) ) {
			$templates = array();
		} 

		// New cache, therefore remove the old one
		wp_cache_delete( $cache_key , 'themes');

		// Now add our template to the list of templates by merging our templates
		// with the existing templates array from the cache.
		$templates = array_merge( $templates, $this->templates );

		// Add the modified cache to allow WordPress to pick it up for listing
		// available templates
		wp_cache_add( $cache_key, $templates, 'themes', 1800 );

		return $atts;

	}

	/**
	 * Checks if the template is assigned to the page
	 */
	public function view_project_template( $template ) {

		global $post;

		if (!isset($this->templates[get_post_meta( 
			$post->ID, '_wp_page_template', true 
		)] ) ) {
			
			return $template;
			
		} 

		$file = plugin_dir_path(__FILE__). get_post_meta( 
			$post->ID, '_wp_page_template', true 
		);

		// Just to be safe, we check if the file exist first
		if( file_exists( $file ) ) {
			return $file;
		} 
		else { echo $file; }

		return $template;

	} 
	
}

add_action( 'plugins_loaded', array( 'PageTemplater', 'get_instance' ) );

?>
