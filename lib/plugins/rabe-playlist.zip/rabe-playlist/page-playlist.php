<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Omega
 */

get_header(); ?>
<main  class="<?php echo omega_apply_atomic( 'main_class', 'content' );?>" <?php omega_attr( 'content' ); ?>>


	<?php 
	do_action( 'omega_before_content' );

	do_action( 'omega_content' );

	// ist noch nicht so schön. aber ich weiss grad noch nicht, wie ich das mit
	// partials oder filter lösen kann.

	// style
	wp_enqueue_style( 'rbpl_css', plugins_url( 'style.css', __FILE__ ) );

	// datum oder so	
	$today = current_time("Y-m-d");  // TODO i18n

	if ( isset($_GET["date"]) ) {
		$playlist_date = $_GET['date'];
		if ( $playlist_date > $today ) {
			$playlist_date = $today;
		}
	} else {
		$playlist_date = $today;
	}
	
	$playlist_date_current = new DateTime($playlist_date);
	$playlist_date_previous = (new DateTime($playlist_date))->sub(new DateInterval('P1D'));
	$playlist_date_next = (new DateTime($playlist_date))->add(new DateInterval('P1D'));
	
	// test. gib mal was aus der db aus.
	$rbpl_playlist = rbpl_db_get_results($playlist_date);

	 /*var_dump($rbpl_playlist); */
	 /* var_dump(rbpl_db_update_table()); */

	
	$last_bc = "";
	$closing_bc_div = "";

//	echo get_option('rbpl_db_version');
	
	echo '<div class="playlist-wrap">';

	// #### TEMP ####
	/*  $installed_ver = get_option( "rbpl_db_version" );
	   echo $installed_ver; */
	// #### END TEMP ####
	
	// klaue hier der einfachheithalber mal die pagination und page-numbers

	$pl_prev_txt = $playlist_date_previous->format('Y-m-d');
	$pl_curr_txt = $playlist_date_current->format('Y-m-d');
	$pl_next_txt = $playlist_date_next->format('Y-m-d');

	$pag = "<div class='playlist-navigation pagination'>
	<a class='page-numbers' href='?date=$pl_prev_txt'><</a>
	<span class='page-numbers current'>$pl_curr_txt</span>";
	if ( $playlist_date_current < new DateTime($today) ) {
		$pag = $pag . "<a class='page-numbers' href='?date=$pl_next_txt'>></a>";
	}
	$pag = $pag . '</div>';

	echo $pag;

	
	
	foreach ($rbpl_playlist as $entry) {
		if ( $entry->broadcast != $last_bc ) { 
			echo $closing_bc_div;
			echo '<div class="playlist-broadcast"><div class="name">';
			if ( $entry->link ) {
				$homeurl = get_home_url();
				echo "<a href='$homeurl/$entry->link' title='$entry->broadcast'>";
			} else {
				echo "<a title='$entry->broadcast'>";
			}
			echo $entry->broadcast;
			echo '</a></div>';
			$closing_bc_div = '</div>';
			$last_bc = $entry->broadcast; // und zeit evt?
		}
		if ( is_null($entry->title) ) {
			echo '<div class="time">';
			echo substr($entry->bc_start, 11, 5);
			echo '&#151;';
			echo substr($entry->bc_end, 11, 5); //
			echo '</div>';
		} else {
			echo '<div class="playlist-track"><div class="track"><span class="artist">';
			echo $entry->artist; //
			echo '</span> - <span class="title">';
			echo $entry->title; //
			echo '<span></div><div class="time">';
			echo substr($entry->start, 11, 5);
			echo '</div></div>';
		}
	}

	echo '</div>';

	echo $pag;
	
	echo '</div>';

	do_action( 'omega_after_content' ); 
	?>
</main><!-- .content -->
<?php get_footer(); ?>
