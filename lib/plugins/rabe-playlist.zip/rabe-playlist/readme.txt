RaBe-Playlist WordPress Plugin
------------------------------------------------------

Hier kommt eine Beschreibung hin.

Einrichten
---------------

Cronjob einrichten. Du weiss ja wie: 'crontab -e' und folgende Zeile (und ein Newline) einfügen. (url anpassen!)

  * *  *   *   *     wget -O /dev/null http://rabeta.abelo.ch/wp-cron.php

Danach das Plugin aktivieren

Eine Seite einrichten und beim Template 'RaBe Playlist' auswählen.

TODO: Das "normale" Wordpress Cron kann aus Performancegründen jetzt eigentlich abgestellt werden.
